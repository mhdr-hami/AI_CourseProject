import math
import random
import time
from threading import Thread
from base import BaseAgent, TurnData, Action


class Node:
    def __init__(self, content, childs: list, cordinate: tuple, row):
        self.cordinate = cordinate
        self.content = content
        self.actionSrc = None
        self.actionGoal = None
        self.parentSrc = -1
        self.parentGoal = -1

        self.childs = childs
        self.index = row * cordinate[0] + cordinate[1]


class Graph:
    def __init__(self, rows, cols, mapp):
        self.index_based_dict = {}
        self.childs_list = []
        self.mapp = mapp
        self.rows = rows
        self.cols = cols

    def fillChilds(self):
        for r in range(self.rows):
            for c in range(self.cols):
                childs = []
                if self.mapp[r][c] == "*":
                    continue
                else:
                    if r + 1 < self.rows:
                        if self.mapp[r+1][c] != "*":
                            ind = self.rows * (r+1) + c
                            childs.append(ind)
                    if r - 1 > -1:
                        if self.mapp[r-1][c] != "*":
                            ind = self.rows * (r-1) + c
                            childs.append(ind)
                    if c + 1 < self.cols:
                        if self.mapp[r][c+1] != "*":
                            ind = self.rows * r + c + 1
                            childs.append(ind)
                    if c - 1 > -1:
                        if self.mapp[r][c-1] != "*":
                            ind = self.rows * r + c - 1
                            childs.append(ind)

                    newNode = Node(self.mapp[r][c], childs, (r, c), self.rows)
                    self.index_based_dict[(self.rows * r) + c] = newNode
                    self.childs_list.append(childs)


class UninformedSearch:
    def __init__(self, g: Graph, bases):
        self.graphSize = g.rows * g.cols
        self.g = g
        self.bases = bases

        self.frontierStart = [False for _ in range(self.graphSize)]
        self.frontierGoal = [False for _ in range(self.graphSize)]

        self.queueStart = []
        self.queueGoal = []

    def baseFind(self):
        for i in self.queueGoal:
            if i in self.bases:
                return i
        return -1

    def intersect(self):
        for i in range(self.g.rows * (self.g.rows-1) + (self.g.cols-1)):
            if self.frontierStart[i] and self.frontierGoal[i]:
                return i
        return -1

    def takeAction(self, pre: int, current: int):
        c0 = self.g.index_based_dict[pre].cordinate
        c1 = self.g.index_based_dict[current].cordinate
        if c0[0] - 1 == c1[0]:
            return "UP"
        if c0[0] + 1 == c1[0]:
            return "DOWN"
        if c0[1] - 1 == c1[1]:
            return "LEFT"
        if c0[1] + 1 == c1[1]:
            return "RIGHT"

    def oneLayerBFS(self):
        tempQueue = []
        while len(self.queueStart) != 0:
            current = self.queueStart.pop(0)
            children = self.g.index_based_dict[current].childs
            for child in children:
                if not self.frontierStart[child]:
                    tempQueue.append(child)
                    self.frontierStart[child] = True
                    self.g.index_based_dict[child].parentSrc = current
                    self.g.index_based_dict[child].actionSrc = self.takeAction(current, child)

        for item in tempQueue:
            self.queueStart.append(item)

        tempQueue = []
        while len(self.queueGoal) != 0:
            current = self.queueGoal.pop(0)
            children = self.g.index_based_dict[current].childs
            for child in children:
                if not self.frontierGoal[child]:
                    tempQueue.append(child)
                    self.frontierGoal[child] = True
                    self.g.index_based_dict[child].parentGoal = current
                    self.g.index_based_dict[child].actionGoal = self.takeAction(current, child)

        for item in tempQueue:
            self.queueGoal.append(item)

    def actReverse(self, act):
        if act == "DOWN":
            return "UP"
        if act == "UP":
            return "DOWN"
        if act == "RIGHT":
            return "LEFT"
        if act == "LEFT":
            return "RIGHT"

    def bidirectionalSearch(self, start: int, goal: int):
        self.frontierStart[start] = True
        self.frontierGoal[goal] = True

        self.queueStart.append(start)
        self.queueGoal.append(goal)

        nearestBaseIndex = self.baseFind()
        intersect_index = self.intersect()

        while True:
            self.oneLayerBFS()
            intersect_index = self.intersect()
            if nearestBaseIndex == -1:
                nearestBaseIndex = self.baseFind()
            if intersect_index != -1:
                break

        while nearestBaseIndex == -1:
            self.oneLayerBFS()
            nearestBaseIndex = self.baseFind()

        answer1 = []
        temp_it = intersect_index
        while temp_it != start:
            answer1.insert(0, self.g.index_based_dict[temp_it].actionSrc)
            temp_it = self.g.index_based_dict[temp_it].parentSrc

        answer2 = []
        temp_it = intersect_index

        while temp_it != goal:
            answer2.append(self.actReverse(self.g.index_based_dict[temp_it].actionGoal))
            temp_it = self.g.index_based_dict[temp_it].parentGoal

        answer3 = []
        temp_it = nearestBaseIndex

        while temp_it != goal:
            answer3.insert(0, self.g.index_based_dict[temp_it].actionGoal)
            temp_it = self.g.index_based_dict[temp_it].parentGoal

        answer = answer1 + answer2 + answer3

        return answer

    def bidirectionalCaller(self, start, goal, passing):
        passing.insert(0, self.bidirectionalSearch(start, goal))


def findInAgents(turn_data: TurnData, x, y):
    for i in range(len(turn_data.agent_data)):
        if turn_data.agent_data[i].position[0] == x and turn_data.agent_data[i].position[1] == y:
            return i
    return -1


def go(act: str):
    if act == "DOWN":
        return Action.DOWN
    if act == "UP":
        return Action.UP
    if act == "RIGHT":
        return Action.RIGHT
    if act == "LEFT":
        return Action.LEFT


def find_diamonds_bases(bmap):
    diamonds = []
    bases = []
    for r in range(len(bmap)):
        for c in range(len(bmap[r])):
            if bmap[r][c] == '1':
                diamonds.append((r, c))
            if bmap[r][c] == "a":
                bases.append(r * len(bmap) + c)

    return diamonds, bases


class safeSearch:
    def __init__(self, map, search: UninformedSearch, timeLimit):
        self.algo = search
        self.timeLimit = float(timeLimit)
        self.darsad = 0.5
        self.solution = []
        self.map = map

    def isValid (self, point: tuple):
        x = point[0]
        y = point[1]
        if (x >= 0) and (x < len(self.map)) and (y >= 0) and (y < len(self.map[0])) and (self.map[x][y] != "*"):
            return True
        return False

    def heuristic(self, current: tuple, goal: tuple):
        return math.sqrt((current[0] - goal[0])**2 + (current[1] - goal[1])**2)

    def fastChoose(self, current, hadaf):
        xStart = current // len(self.map[0])
        yStart = current % len(self.map[0])

        xGoal = hadaf // len(self.map[0])
        yGoal = hadaf % len(self.map[0])
        goal = (xGoal, yGoal)

        up = (xStart - 1, yStart)
        down = (xStart + 1, yStart)
        left = (xStart, yStart - 1)
        right = (xStart, yStart + 1)

        d = []

        if self.isValid(up):
            d.append((self.heuristic(up, goal), "UP"))
        if self.isValid(down):
            d.append((self.heuristic(down, goal), "DOWN"))
        if self.isValid(left):
            d.append((self.heuristic(left, goal), "LEFT"))
        if self.isValid(right):
            d.append((self.heuristic(right, goal), "RIGHT"))
        return [max(d)[1]]

    def limitSolver(self, start, goal):
        start_time = time.time()
        t1 = Thread(target=self.algo.bidirectionalCaller, args=(start, goal, self.solution))
        end_time = time.time()
        tTime = end_time - start_time

        print(tTime)
        print("isalive1:", t1.is_alive())

        t1.start()

        while True:
            if self.timeLimit - (time.time() - start_time) <= 0.002:
                break

        print("isalive2:", t1.is_alive())
        # if (self.timeLimit - tTime) > 0:
        #     time.sleep(self.darsad * (self.timeLimit - tTime))
        # else:
        #     print("Fast Choose due to Thread Overhead")
        #     return self.fastChoose(start, goal)

        print("isalive3:", t1.is_alive())

        if t1.is_alive():
            print("Fast Choose")
            return self.fastChoose(start, goal)
        else:
            print("Javab Asli")
            return self.solution[0]


class Agent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.solution = []
        self.diamonds_cors = []
        self.base_cors = []
        self.graph = None
        self.algo = None
        self.state = 0

    def do_turn(self, turn_data: TurnData) -> Action:

        if self.state == 0:
            agent_cordinate = turn_data.agent_data[0].position
            self.diamonds_cors, self.base_cors = find_diamonds_bases(turn_data.map)
            self.graph = Graph(len(turn_data.map), len(turn_data.map[0]), turn_data.map)
            self.graph.fillChilds()
            self.algo = UninformedSearch(self.graph, self.base_cors)
            start = agent_cordinate[0] * len(turn_data.map[0]) + agent_cordinate[1]
            goal = self.diamonds_cors[0][0] * len(turn_data.map[0]) + self.diamonds_cors[0][1]
            safeSearcher = safeSearch(turn_data.map, self.algo, self.decision_time_limit)
            # self.solution = self.algo.bidirectionalSearch(start, goal)
            self.solution = safeSearcher.limitSolver(start, goal)
            print(self.solution)
            act = self.solution.pop(0)
            if self.solution:
                self.state = 1
            return go(act)

        if self.state == 1:
            if self.solution:
                if len(self.solution) == 1:
                    self.state = 1
                act = self.solution.pop(0)
                return go(act)


if __name__ == '__main__':
    winner = Agent().play()
    print("WINNER: " + winner)